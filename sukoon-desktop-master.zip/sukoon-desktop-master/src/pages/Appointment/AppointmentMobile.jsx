import React from "react";
import styled from "styled-components";

// Components

// Images


const Wrapper = styled.div`
  
`;


function AppointmentMobile(props) {

  return (
    <>
      <Wrapper className={`flex`}>
        <h1 className={`text-sukoon text-xl mt-16 mx-auto`}>Welcome to video appointment</h1>
      </Wrapper>
    </>
  );
}

export default AppointmentMobile;
