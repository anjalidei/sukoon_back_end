import React from "react";
import styled from "styled-components";

// Components

// Images

// Styled Components

const Wrapper = styled.div`
  
`;


function AppointmentDesktop(props) {

  return (
    <>
      <Wrapper className={`flex`}>
        <h1 className={`text-sukoon mt-16 mx-auto`}>Welcome to video appointment</h1>
      </Wrapper>
    </>
  );
}

export default AppointmentDesktop;
