import React, {useState} from "react";
import styled from "styled-components";

// Components
import Title from "../../elements/Heading/mobile";
import Para from "../../elements/Para/mobile"
import MeetExperts from "../../components/MeetExperts/mobile";
import Banner from "../../components/Banner/mobile";
import Tab from "../../elements/Tabs/TabsMobile";

// Images
import BannerBg from "../../images/servicesBg.png";

const ServiceType = styled.div`
`;

const TabList = styled.ul`
   min-height: 40px;
   height: 60px;
`;

const Content = {
  Main: 'Clinical Psychology',
  Summary:  ` At Sukoon, we have a team of licensed clinical psychologists who
   are recognised by the Rehabilitation Council of India. They are experts in 
   carrying out psychometric and diagnostic evaluations for:
   1.Developmental delays - Speech disorders, behavioural disorders, motor disorders, autism etc 

   2.Intellectual and academic functioning - Learning disabilities, dyslexia, ADHD, ADD etc

   3.Clinical Psychopathology - Anxiety, OCD, phobia, depression, bipolar, psychosis, schizophrenia  etc

   4.Personality patterns - Borderline traits, anxious avoidant, obsessive compulsive traits, narcissism etc   

   5.Neuropsychological functioning - Dementia, cognitive disorders, memory decline etc`,
  items:[
    
    {
      title: 'Our Approach',
      para: `Our team of clinical psychologists along with psychiatrists specialize in 
      the diagnosis and treatment of clinical, emotional, adjustment, and behavioural 
      disorders. At Sukoon, we are committed to improving the overall quality of our
       patients’ lives, and not just relieve the symptoms temporarily. We offer a wide 
       array of psychotherapy services in individual, couple, family and group formats.
        This brings about lasting and meaningful changes to our patient’s life. Our
         dedicated team of mental health professionals
       provide empathetic and personalized care round the clock.`,
    }
  ]
};
const Content2 = {
  Main: 'COUNSELING PSYCHOLOGY',
  Summary:  ` Our Counselling Psychologists (therapists) facilitate coping for 
  individuals and families with life situations that may be overwhelming or 
  debilitating. At Sukoon, we focus on how people function individually, in families, and socially.
   Our world class team of mental health professionals provide holistic care for:
   1.Relationship counselling: Marital counselling, family therapy, partner conflict, pre-marital counselling, domestic violence, intimate partner abuse etc.
   2.Academic counselling: School stress, exam stress, higher education concerns, bullying, peer pressure, anxiety etc.
   3.Workplace counselling: Work life balance, career decision making, retirement transition, conflict resolution, organizational problems etc.
   4.LGBTQ+ mental health concerns - Coming out, family counselling, homonegativity, GID certification, queer informed relationship counselling, handling gender based discrimination etc.
   5.Learning and skill building: Confidence building, assertiveness training, time management, communication difficulties etc .
   6.Coping with physical disabilities, disease or injury.
   7.Counselling for Caregivers.
   8.Anger management.
   9.Stress management.`,
  items:[
    {
      title: 'Our Approach',
      para: `At Sukoon, we take therapist-patient confidentiality seriously. Throughout our facility we have taken measures to ensure that your conversations remain private. Our therapy rooms are equipped with the following amenities:
      1.Comfortable seating (sofas, high chairs - take your pick)

      2.Spacious rooms with ample sunlight
  
      3.White noise sound machines to prevent eavesdropping
  
      4.Plants, plants, and more plants!`
    }
    
  ]
};

const Content3 = {
  Main: 'Art Based Therapy .',
  Summary:  ` At Sukoon, we have a team of art based therapists certified by British Association of Art Therapy, Health and Care Professions Council-UK, and UNESCO- Conseil International de la Danse. Art Based Therapy is helpful with patients who have difficulty in verbal expression. We use Art Based therapy as an alternative to therapy for:
  1.Psychiatric disorders  such as depression, anxiety, OCD, psychosis, bipolar disorder etc

  2.Behavioral disorders such as aggressive outbursts, disregarding authority etc 

  3.Developmental disorders such as ADHD, ADD, individuals with special needs etc

  4.Trauma and abuse 

  5.Anger Management.
  For individuals, groups, and corporates we use Art Based Therapy to address the following:
  1.Confidence and motivation building

  2.Leadership skills

  3.Stress management

  4.Assertiveness

  5.Interpersonal skills and building effective communication patterns

  6.Coping with serious or chronic illness

  7.Facilitating support groups
  `,
  items:[
    {
      title: 'Our Approach',
      para: `Our priority is to help facilitate a patient's expression. For this we use various mediums such as visual arts - drawing, painting, clay, crafts, pottery, sculpture, 3-D modelling, music, storytelling, creative writing, movement, and dance. Every patient is unique and hence, we personalise treatment as per their comfort, and needs. At Sukoon our aim is to create a safe, non-judgemental, and contained space with all our patients via an independent art therapy studio that boasts of:
      1.A spacious glass room on the terrace 

      2.A lush green terrace garden for outdoor activities
  
      3.Variety art materials (paints, potter’s clay, coffee beans, textile etc - take your pick! )
  
      4.Private and confidential storage space.
      Sukoon explores art based therapy across all age groups, skill and functioning levels by involving different creative techniques.
     `
    }
   
  ]
};

const Content4 = {
  Main: 'rTMS Treatment',
  Summary:  ` Repetitive Transcranial Magnetic Stimulation (rTMS) is a non-invasive and non-pharmacological  (no anaesthesia or medication required) treatment. It is an absolutely painless (both physical and psychological) alternative to traditional treatment methods. As the patient is not taking any medication, rTMS also reduces any side effects. This makes it convenient as hospitalization is not required and there is no post session “recovery time”.
  At Sukoon we use world class rTMS machines to provide relief from psychiatric and organic conditions such as:
  1.Depression

  2.Anxiety Disorders

  3.Obsessive Compulsive Disorder (OCD)

  4.Addiction problems (for craving management)

  5.Auditory hallucinations

  6.Autism

  7.Bipolar affective disorder

  8.Chronic Schizophrenia

  9.Attention Deficit Hyperactivity Disorder

  10.Eating disorders

  11.Chronic Tinnitus

  12.Parkinson’s disease
`,
  items:[
    {
      title: 'Our approach',
      para: `At Sukoon we strive to make the rTMS treatment as comfortable as possible for the patient as well as their caregivers by providing:
      1.Our rTMS sessions are brief (typically last between 15- 45 minutes)

      2.A dedicated therapy room to comfortably seat the patients along with their family, friends, or attendants
  
      3.Highly trained and caring technical staff
  
      4.Lush green environment
  
      5.60” inches TV with a video menu  
      Our team is highly experienced in providing rTMS therapy and ensures personalized care. `

    }
   
  ]
};

const Content5 = {
  Main: 'REMEDIATION.',
  Summary:  `Special educators, through the use of specific and multi-sensory techniques and
   individualized education plans, assist children with learning disabilities, 
   intellectual disabilities and attention deficits to cope with their academic 
   demands. Occupational therapy aims at restoring cognitive and motor functioning 
   in children with developmental disorders, while also modifying tasks and teaching 
   skills to carry out activities of daily living. `,
  
};
const Content6 = {
  Main: 'PSYCHOANALYTIC THERAPYt',
  Summary:  ` At Sukoon, our psychoanalytic therapists have received extensive training in bringing unconscious thoughts and feelings to the conscious mind. This allows for repressed experiences and emotions, often from childhood, to be brought to the surface and examined. It helps 
  patients understand and resolve their problems by increasing their awareness of their inner world and its influence on relationships, both past and present. This Freudian and post Freudian approach of therapy provides an effective treatment for a range of psychological disorders such as
  1.Personality disorder:  Borderline, histrionic, anxious avoidant, narcissistic, dependent, etc

  2.Relationship issues: Attachment difficulties, interpersonal conflicts, relational dynamics, etc

  3.Psychosomatic disorders: Unexplained aches and pains, illness anxiety, conversion, etc

  4.Self-destructive behavior: Self harm behaviours, excessive risk taking, aggressive drives

  5.Neurotic behaviour pattern: Eating disorder, Obsessive compulsive traits, etc

  6.Identity problems: Fixation, self perception and self image, incongruence, etc

  7.Dissociation: Depersonalisation, derealisation, etc

  8.Anxiety and Phobia

  9.Emotion struggles or trauma

  10.Sexual problems

  11.Depression
`,
  items:[
    {
      title: 'Our approach',
      para: `At Sukoon, we are committed to creating safe therapeutic space that facilitate rapport building and self disclosure and hence therapist-patient confidentiality is our top most priority. Throughout our facility we have taken measures to ensure that your conversations remain private. 
      Our therapy rooms are equipped with the following amenities:
      1.Comfortable couch

      2.Spacious rooms with ample sunlight
  
      3.White noise sound machines to prevent eavesdropping
  
      4.Plants, plants, and more plants!
  
  We are committed to improving the overall quality of our patients’ lives, and not just relieve the symptoms temporarily. This brings about lasting and meaningful change to our patient’s life. Our dedicated team of psychoanalytic psychotherapists provide empathetic and personalized care.`

    }
   
  ]
};

const Content7 = {
  Main: 'OCCUPATIONAL THERAPY',
  Summary:  ` Mental illness is the leading cause of disability in the world.
   At Sukoon, we offer Occupational therapy, which is the use of assessment and 
   intervention to develop, recover, or maintain meaningful activities, or occupations, of individuals, groups, or communities. It helps people across their lifespan to participate in the things they want and
   need to do through the therapeutic use of everyday activities (occupations).
   The occupational therapists at Sukoon provide services that support mental and 
   physical health and wellness, rehabilitation and recovery of the patient.

   We/ they address barriers to optimal functioning through interventions that 
   focus on enhancing existing skills, creating opportunities, remediating or restoring skills, modifying or adapting the environment or activity and preventing relapse.
`
};
const Content8 = {
  Main: 'VIRTUAL THERAPY',
  Summary:  `Virtual therapy or online therapy involves providing mental health services and support over the internet. At Sukoon, we offer virtual therapy where our team of experts: Psychiatrists, Clinical Psychologists and Art-based therapists are available for video conferencing. This makes  the treatment convenient, economical, and accessible alternative for face to face therapy.
`,
  items:[
    {
      title: 'Our approach',
      para: `At Sukoon we strive to make the treatment as comfortable as possible for the patient as well as their caregivers by providing:
      1.A dedicated virtual therapy room

      2.Software system to ensure your conversations stay private
  
      3.Full High Definition  
  
      4.Online, hassle free and convenient billing options
  
      5.Email delivery of a prescription by the Psychiatrist
      Sukoon values your wellbeing and your needs. We understand the importance of therapy and psychiatric consultations. Therefore, our clinical team aims to make its treatment as accessible as possible by bridging the distance through our virtual therapy facility . `

    }
   
  ]
};
const Content9 = {
  Main: 'PSYCHO-ONCOLOGY',
  Summary:  `Psycho-oncology therapy deals with the psychological, social, behavioral and ethical aspects of cancer. At Sukoon, we aim at providing psychological as well as emotional support to the patients and their caregivers to fight cancer and help cope with it.

 

  It also helps/assists with destigmatization of cancer and of mental illness, addresses the changes in the relationship between the caregiver and the patient, assists the change in focus from increasing survival and life expectancy to improving quality of life and development of palliative care.
  The treatment involves:

  1.  	Understanding psycho-oncology
  
  2. 	Comprehensive psychosocial assessment for cancer patients and application of a range of psychological intervention for them
  
  3. 	Interventions to enhance coping skills in cancer
  
  4. 	Improving communication and interpersonal skills in cancer care
  
   
  
  We offer individual and support group therapy sessions through which counseling is provided for different sets of patients.`
 
};


const OutPatienList = [
  {name: 'Clinical psychology ' , content: Content, number: '1'},
  {name: 'Counselling psychology', content: Content2, number: '2'},
  {name: 'Art-Based Therapy', content: Content3, number: '3'},
  {name: 'rTMS Treatment', content: Content4, number: '4'},
  {name: 'Remediation', content: Content5, number: '5'},
  {name: 'Psychoanalytical  Therapy', content: Content6, number: '6'},
  {name: 'Occupational Therapy', content: Content7, number: '7'},
  {name: 'Virtual Therapy', content: Content8, number: '8'},
  {name: 'Psycho - Oncology ', content: Content9, number: '9'},
];

const ResidentialServicesList = [
  {name: 'Acute Psychiatry Care' , content: Content, number: '1'},
  {name: 'Intensive Care Unit', content: Content2, number: '2'},
  {name: 'Alcohol Deaddiction', content: Content3, number: '3'},
  {name: 'Drug Deaddiction', content: Content4, number: '4'},
  {name: 'Habit Deaddiction', content: Content5, number: '5'},
  {name: 'Sukoon At Home', content: Content, number: '6'},
  {name: 'Geriatric Psychiatry', content: Content, number: '7'},
  {name: 'Women Focused Care', content: Content, number: '8'},
  {name: 'Child Psychiatry', content: Content, number: '9'},
];

const InfoSection = (props) =>{

  return(
    <div className={`${props.wrapperClass || ''}`}>
      <h3 className="font-gilroyMedium mt-3 text-left text-sukoon leading-none">{props.title}</h3>
      <Para>
        {props.content}</Para>
    </div>
  )
};

const CareService = (props) =>{

  const[ListContent, setContent] = useState(Content);

  function handleView(content){
    // Content bellow the tab is changed by the next function.
    setContent(content);
  }

  return(
    <section id={props.titleLight} className="p-4">
      <Title titleLight={props.titleLight} subHeading={props.subheading} titleBold={props.titleBold} display="block"/>
      <div className="flex flex-wrap overflow-x-hidden ">
        <TabList className="patient_services_nav flex overflow-y-hidden overflow-x-scroll">
          {props.list.map((item)=>{
            return (
            <li className="mt-3">
            <Tab onClick={handleView} argument={[item.content]} active={ ListContent === item.content} buttonClass={``}>
              {item.name}
            </Tab>
            </li>
            )
          })}
        </TabList>
        <ServiceType className="service_content mt-2 overflow-x-hidden text-justify">
          {ListContent.items.map((content)=>{
            return(
              <InfoSection title={content.title} content={content.para} />
            )
          })}
        </ServiceType>
      </div>
    </section>
  )
};

function Services(props) {

  return (
    <>
      <Banner captionLight={`Feel like`} bannerPara={`We’re here for you. At Sukoon, our experienced team of psychiatrists, clinical psychologists, therapists, and nurses provide compassionate, short-term and inpatient psychiatric and mental health services that help you feel better as quickly as possible. We work with you one-on-one ensuring that every part of your care is personalised to your condition, emotions, and needs.`} captionBold={`Yourself Again`}  overlay={props.overlay} backgroundImg={BannerBg}/>
      <CareService list={ResidentialServicesList} subHeading={`IPD`} titleLight="Residential" titleBold="Care Services"/>
      <CareService list={OutPatienList} subHeading={`OPD`} titleLight="Out Patient" titleBold="Care Services"/>
      <MeetExperts/>
    </>
  );
}

export default Services;
